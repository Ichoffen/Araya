// Renderer работает через fetch к http://localhost:3131 (локальный API)
